﻿namespace CloneCustomer
{
    public interface IDisplayable
    {
        public string GetDisplayText();
    }
}