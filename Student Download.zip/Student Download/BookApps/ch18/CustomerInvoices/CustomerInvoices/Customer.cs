﻿namespace CustomerInvoices;

public class Customer
{
    public int CustomerID { get; set; }
    public string Name { get; set; } = "";
}
