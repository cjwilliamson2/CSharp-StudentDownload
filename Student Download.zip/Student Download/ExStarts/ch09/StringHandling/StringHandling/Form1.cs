namespace StringHandling;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
    }

    private void btnParseName_Click(object sender, EventArgs e)
    {
        // TODO: Add code to parse name
    }

    private void btnEditPhoneNumber_Click(object sender, EventArgs e)
    {
        // TODO: Add code to edit the phone number
    }

    // TODO: Add ToInitialCap method here

    private void btnExit_Click(object sender, EventArgs e)
    {
        this.Close();
    }
}
