namespace DateHandling;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
    }

    private void btnCalculateDays_Click(object sender, EventArgs e)
    {
        // TODO: Add code to calculate the days until due date
    }

    private void btnCalculateAge_Click(object sender, EventArgs e)
    {
        // TODO: Add code to calculate the age
    }

    private void btnExit_Click(object sender, EventArgs e)
    {
        this.Close();
    }
}
